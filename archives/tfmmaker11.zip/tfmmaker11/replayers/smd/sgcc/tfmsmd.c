#include "genesis.h"
#include "music.h"
#include "tfcplayer_sgcc.h"



ulong vtimer;   /* VBL timer */



uint vdp_init_data[]={
    0x8006,0x8174,0x8238,0x8338,0x8406,0x857e,0x8600,0x8700,0x8801,
    0x8901,0x8a00,0x8b00,0x8c81,0x8d00,0x8f02,0x9001,0x9100,0x92ff
};



void main()
{
    register uint *pw;
    register ulong x;
    register uint i,frameCount,comp60hz;
 
    pw=(uint*)GFXCNTL;
 
    for(i=0;i<18;i++) *pw=vdp_init_data[i];
 
    pw=(uint*)0xa10001; /* use speed compensation for NTSC console */
    comp60hz=(*pw&0x40)?FALSE:TRUE;
 
    frameCount=0;

    tfc_init(music_data);
    tfc_play(TRUE);
 
    while(1)
    {
        x=vtimer;
        while(x==vtimer);
 
        if(comp60hz)
        {
            if(frameCount%10) tfc_frame();
        }
        else
        {
            tfc_frame();
        }
 
        frameCount++;
    }
}