How to compile example:

You need AS Assembler and SjAsm:

http://sega-devega.net/ASAsm.zip
http://home.planet.nl/~realfun/sjasm.html

Place AS Assembler into directory /asasm/ and SjAsm to directory /sjasm/
(see compile.bat for details).

To convert music you also need TFMCOM utility which included into editor
package, and any music, exported as TFD from editor under name music.tfd

Player works into Z80 RAM. I tried to make sync on 50 Hz (because tracker
always use 50 Hz update frequency) by YM2612 timer, like in Zyrinx games,
but I'm not sure if it works properly.

Music data (*.TFC file) must be placed within boundaries of one ROM bank.
I.e., crossing of bank boundaries is not supported by player (it plays
data as six independent LZ-like packed streams, so it's hard to add bank
switching). Within range of one bank any offset can be used.