TFD replayer in pure BasiEgaXorz (http://devster.monkeeh.com/sega/basiegaxorz/)

Code still has one unsolved problem.  By some  reasons, when I try to do busreq
on/off  in replayer's  update  function,  code is hangs  (see for two commented
lines). I left this problem to you, fix it if you want to run your code on real
console. Without fix it will work fine in emulator only.