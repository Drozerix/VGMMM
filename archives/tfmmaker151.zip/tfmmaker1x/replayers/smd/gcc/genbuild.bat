PATH=..\bin\
tfmcom music.tfd
bin2h music.tfc

call e:\gendev\bin\genpath.bat
del *.o
del rom.out
del rom.bin
make -f makefile.gen

del *.out
del *.o
del *.tfc
del music.h