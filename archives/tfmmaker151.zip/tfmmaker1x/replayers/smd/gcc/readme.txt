How to compile example:

You need M68K GCC, for example one from Genesis Mini DevKit:

http://www.spritesmind.net/_GenDev/forum/viewtopic.php?t=14

Setup compiler (see compile.bat and makefile.gen for details). Note that
example does not use any standart libraries from Mini DevKit.

To convert music you also need TFMCOM utility which included into editor
package, and any music, exported as TFD from editor under name music.tfd

This C version uses only M68K to play music. It's relatively slow, but has
no limitation with crossing bank boundaries like Z80 version has.