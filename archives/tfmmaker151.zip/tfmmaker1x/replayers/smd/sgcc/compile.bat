PATH=..\bin\
tfmcom music.tfd
bin2h music.tfc
make
del *.o
del tfmsmd.s
del *.tfc