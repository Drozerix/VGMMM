How to compile example:

You need Sozobon C Compiler:

http://www.spritesmind.net/_GenDev/index.php?page=sgcc

Setup compiler, put /bin/ directory in PATH (see compile.bat for details).

To convert music you also need TFMCOM utility which included into editor
package, and any music, exported as TFD from editor under name music.tfd

This C version uses only M68K to play music. It's relatively slow, but has
no limitation with crossing bank boundaries like Z80 version has.