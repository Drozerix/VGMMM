sjasm\sjasm z80drv.asm
del z80drv.bin
ren z80drv.out z80drv.bin
tfmcom\tfmcom music.tfd
asasm\bin\as tfmsmd.asm
asasm\bin\p2bin tfmsmd.p
pause
del *.p
del z80drv.bin
del *.lst
del *.tfc